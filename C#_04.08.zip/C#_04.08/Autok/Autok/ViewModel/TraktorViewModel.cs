﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViewModels.BaseClass;
using Autok.Model;
using System.Windows;

namespace Autok.ViewModel
{
    public class TraktorViewModel:ViewModelBase
    {
        public Traktor t;

        public RelayCommand Kilepes {  get; set; }
        public RelayCommand Szamitas { get; set; }

        public TraktorViewModel()
        {
            t = new Traktor();
            Kilepes = new RelayCommand(execute => CloseCommand());
            Szamitas = new RelayCommand(execute => Calculate());
        }
             public double Nyomatek
        {
            get
            {
                return t.Nyomatek;
            }
            set
            {
                t.Nyomatek = value;
            }
        }

        public double Fordulatszam
        {
            get
            {
                return t.Fordulatszam;
            }
            set
            {
                t.Fordulatszam = value;
            }
        }
        public double Loero
        {
            get
            {
                return t.Loero;
            }
        }

        public double Fekloero
        {
            get
            {
                return t.Fekloero;
            }
        }

        public void CloseCommand()
        {
            Application.Current.MainWindow.Close();
        }

        public void Calculate()
        {
            OnPropertyChanged(nameof(Loero));
            OnPropertyChanged(nameof(Fekloero));
        }
    }
}
