﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Autok.Model
{
    public class Traktor
    {
        public double nyomatek;
        public double fordulatszam;
        public double loero;
        public double fekloero;
        
        public double Nyomatek
        {
            get
            {
                return nyomatek;
            }
            set
            {
                nyomatek = value;
            }
        }

        public double Fordulatszam
        {
            get
            {
                return fordulatszam;
            }
            set
            {
                fordulatszam = value;
            }
        }
        public double Loero
        {
            get
            {
                loero = Math.Round(nyomatek * fordulatszam / 5252, 1);
                return loero;
            }
        }

        public double Fekloero
        {
            get
            {
                fekloero = Math.Round(loero * 0.99, 1);
                return fekloero;
            }
        }
    }
}
