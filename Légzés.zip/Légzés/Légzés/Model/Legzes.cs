﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;

namespace Légzés.Model
{
    public class Legzes
    {
        public double szendioxid = 1;
        public double oxigen = 1;
        public double hanyados;
        public string ertekeles;

        public double Szendioxid
        {
            get
            {
                return this.szendioxid;
            }
            set
            {
                this.szendioxid = value;
            }
        }
        public double Oxigen
        {
            get
            {
                return this.oxigen;
            }
            set
            {
                this.oxigen = value;
            }
        }
        public double Hanyados
        {
            get
            {
                hanyados = szendioxid / oxigen;
                return hanyados;
            }
        }
        public string Ertekeles
        {
            get
            {
                if(hanyados < 0.8)
                {
                    ertekeles = "A szervezet a zsirokbol veszi az energiat";
                }
                else if(hanyados == 0.8)
                {
                    ertekeles = "Megfelelo ertek";
                }
                else
                {
                    ertekeles = "A szervezet a szenhidratbol veszi az energiat";
                }
                return ertekeles;
            }
        }

    }
}
