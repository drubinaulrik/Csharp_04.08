﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Légzés.Model;
using ViewModels.BaseClass;

namespace Légzés.viewmodel
{
    class LegzesViewmodel : ViewModelBase
    {
        public Legzes l;
        public RelayCommand Calculate {  get; set; }

        public LegzesViewmodel()
        {
            l = new Legzes();
            Calculate = new RelayCommand(execute => Calc());
        }

        public double Szendioxid
        {
            get
            {
                return l.Szendioxid;
            }
            set
            {
                l.Szendioxid = value;
            }
        }
        public double Oxigen
        {
            get
            {
                return l.Oxigen;
            }
            set
            {
                l.Oxigen = value;
            }
        }
        public double Hanyados
        {
            get
            {
                return l.Hanyados;
            }
        }
        public string Ertekeles
        {
            get
            {
                return l.Ertekeles;
            }
        }
        public void Calc()
        {
            OnPropertyChanged(nameof(Hanyados));
            OnPropertyChanged(nameof(Ertekeles));
        }
    }
}
